<head>
    <title>Sex Shop Sexy Diversión</title>
    <meta charset="UTF-8">
    <meta name="author" content="Surftware">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- favicon -->

    <!-- Plugin CSS -->
    <link rel="stylesheet" type="text/css" href="css/superslide/superslides.css">
    <link rel="stylesheet" type="text/css" href="css/themes/default/default.css">
    <link rel="stylesheet" type="text/css" href="js/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="js/slick/slick-theme.css">
    <link rel="stylesheet" type="text/css" href="css/animate/animate.css">
    <link rel="stylesheet" type="text/css" href="css/featherlight/featherlight.css" />
    <link rel="stylesheet" type="text/css" href="css/featherlight/featherlight.gallery.css" />
    <!-- Custom Template CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>